// Bilder-Datenbank — füge hier deine eigenen URLs hinzu
export const IMAGES: { id: string; url: string; title: string }[] = [
  { id: "1", url: "https://heavenlynnhealthy.de/wp-content/uploads/2020/05/panzanella-erdbeeren-hoch-768x1152.jpg", title: "Erdbeer-Panzanella" },
  { id: "2", url: "https://cdn.prod.www.spiegel.de/stories/153141/assets/1/f-3-butter-chicken-tofu-hochkant-90291734439057866.jpeg", title: "Indisch" },
  { id: "3", url: "https://heavenlynnhealthy.de/wp-content/uploads/2020/08/ofenreis-hochkant.jpg", title: "ofenreis" },
  { id: "4", url: "https://www.heavenlynnhealthy.com/wp-content/uploads/2018/11/weihnachtspla%CC%88tzchen-hochkant.jpg", title: "weihnachtsplätzchen" },
  { id: "5", url: "https://heavenlynnhealthy.de/wp-content/uploads/2020/09/blumenkohl-wings-hochkant.jpg", title: "blumenkohl-wings" },
  { id: "6", url: "https://i0.wp.com/shop.kochdichturkisch.de/wp-content/uploads/2024/11/kartoffelsalat_yesil_fasulyeli_patates_salatasi_9951_20241111__IMG_5477_hochkant.webp?resize=675%2C1200&quality=80&ssl=1", title: "kartoffelsalat" },
  { id: "7", url: "https://twopotatoes.de/wp-content/uploads/2026/05/zucchinipuffer-header-hochkant-360x361.jpg", title: "zucchinipuffer" },
  { id: "8", url: "https://www.davert.de/media/image/9a/ac/d3/amaranth-granola-hochkant_1280x1280.jpg", title: "amaranth-granola" },
  { id: "9", url: "https://www.wheaty.de/wp-content/uploads/2024/08/Wheaty-Vegane-Pizza-Bresaola-hochkant-scaled.jpg", title: "Vegane Pizza Bresaola" },
  { id: "10", url: "https://cdn.prod.www.spiegel.de/stories/34036/assets/1/f-mayak-eggs-drogen-eier-auswahl-fertig-hochkant-103491661944366310.jpeg?t=1692618138000", title: "mayak-eggs" },
];

const KEY = "liked_images";

export function getLiked(): string[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function toggleLike(id: string): string[] {
  const liked = getLiked();
  const next = liked.includes(id) ? liked.filter((x) => x !== id) : [...liked, id];
  localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event("liked-changed"));
  return next;
}
