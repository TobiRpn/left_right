import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/info")({
  head: () => ({ meta: [{ title: "Info — Bilder Scroll" }] }),
  component: InfoPage,
});

function InfoPage() {
  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">ⓘ Info</h1>
          <Link to="/" className="text-sm bg-white/20 px-4 py-2 rounded-full hover:bg-white/30">
            ← Zurück
          </Link>
        </div>

        <div className="space-y-4 text-white/80 leading-relaxed">
          <p>
            Willkommen in der <strong>Bilder Scroll App</strong>!
          </p>
          <p>
            Scrolle nach unten, um durch die Bilder zu blättern. Jeder Scroll bringt dich
            zum nächsten Bild. Drücke das ♡-Symbol, um ein Bild zu deinen Favoriten
            hinzuzufügen.
          </p>
          <p>
            Über den ★-Button siehst du deine Liste der gelikten Bilder. Likes werden lokal
            in deinem Browser gespeichert.
          </p>
          <p className="text-sm text-white/50 pt-6">
            Prototyp gebaut mit React & TanStack Start.
          </p>
        </div>
      </div>
    </div>
  );
}
