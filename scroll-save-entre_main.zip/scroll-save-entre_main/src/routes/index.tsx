import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, useRef } from "react";
import { IMAGES, getLiked, toggleLike } from "../lib/images";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bilder Scroll" },
      { name: "description", content: "Scroll durch Bilder, like deine Favoriten." },
    ],
  }),
  component: ScrollPage,
});

function ScrollPage() {
  const [liked, setLiked] = useState<string[]>([]);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLiked(getLiked());
    const h = () => setLiked(getLiked());
    window.addEventListener("liked-changed", h);
    return () => window.removeEventListener("liked-changed", h);
  }, []);

  // Dieser Teil sorgt dafür, dass man am PC auch mit dem normalen Mausrad horizontal scrollen kann
  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      container.scrollLeft += e.deltaY;
    };

    container.addEventListener("wheel", handleWheel, { passive: false });
    return () => container.removeEventListener("wheel", handleWheel);
  }, []);

  return (
    /* HIER SIND DIE ÄNDERUNGEN: flex-row, overflow-x-scroll und snap-x */
    <div 
      ref={scrollContainerRef}
      className="flex flex-row h-screen w-screen overflow-x-scroll snap-x snap-mandatory bg-black"
    >
      {IMAGES.map((img) => {
        const isLiked = liked.includes(img.id);
        return (
          <section
            key={img.id}
            /* flex-shrink-0 sorgt dafür, dass die Bilder auf voller Breite bleiben */
            className="relative h-screen w-screen flex-shrink-0 snap-start flex items-center justify-center"
          >
            <img
              src={img.url}
              alt={img.title}
              className="max-h-full max-w-full object-contain"
              draggable={false}
            />
            <div className="absolute top-4 left-4 right-4 text-white text-lg font-medium drop-shadow">
              {img.title}
            </div>
            <div className="absolute bottom-8 left-0 right-0 flex justify-center gap-4 px-4">
              <button
                onClick={() => toggleLike(img.id)}
                className={`flex-1 max-w-[140px] rounded-full py-3 text-2xl font-semibold backdrop-blur ${
                  isLiked ? "bg-red-500 text-white" : "bg-white/20 text-white hover:bg-white/30"
                }`}
                aria-label="Like"
              >
                {isLiked ? "♥" : "♡"}
              </button>
              <Link
                to="/liked"
                className="flex-1 max-w-[140px] rounded-full py-3 text-base font-semibold bg-white/20 text-white backdrop-blur hover:bg-white/30 flex items-center justify-center"
              >
                ★ Liste
              </Link>
              <Link
                to="/info"
                className="flex-1 max-w-[140px] rounded-full py-3 text-base font-semibold bg-white/20 text-white backdrop-blur hover:bg-white/30 flex items-center justify-center"
              >
                ⓘ Info
              </Link>
            </div>
          </section>
        );
      })}
    </div>
  );
}