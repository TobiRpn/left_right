import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { IMAGES, getLiked, toggleLike } from "../lib/images";

export const Route = createFileRoute("/liked")({
  head: () => ({ meta: [{ title: "Likes — Bilder Scroll" }] }),
  component: LikedPage,
});

function LikedPage() {
  const [liked, setLiked] = useState<string[]>([]);
  useEffect(() => setLiked(getLiked()), []);

  const items = IMAGES.filter((i) => liked.includes(i.id));

  return (
    <div className="min-h-screen bg-black text-white p-4">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">♥ Meine Likes</h1>
        <Link to="/" className="text-sm bg-white/20 px-4 py-2 rounded-full hover:bg-white/30">
          ← Zurück
        </Link>
      </div>

      {items.length === 0 ? (
        <p className="text-white/60 text-center mt-20">
          Noch keine Bilder geliked. Drücke ♡ beim Scrollen!
        </p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {items.map((img) => (
            <div key={img.id} className="relative aspect-[3/4] rounded-lg overflow-hidden group">
              <img src={img.url} alt={img.title} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
                <span className="text-sm font-medium">{img.title}</span>
                <button
                  onClick={() => {
                    toggleLike(img.id);
                    setLiked(getLiked());
                  }}
                  className="bg-red-500 w-8 h-8 rounded-full text-lg"
                  aria-label="Unlike"
                >
                  ♥
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
